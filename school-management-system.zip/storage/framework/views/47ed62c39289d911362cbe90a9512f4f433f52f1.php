<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('library.Book List')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('library.Book List')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('library.create')); ?>" class="btn btn-success btn-sm" role="button"
                                   aria-pressed="true"><?php echo e(trans('library.Add a new book')); ?></a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(trans('library.books name')); ?></th>
                                            <th><?php echo e(trans('library.name teacher')); ?></th>
                                            <th><?php echo e(trans('library.Educational level')); ?></th>
                                            <th><?php echo e(trans('library.Classroom')); ?></th>
                                            <th><?php echo e(trans('library.Section')); ?></th>
                                            <th><?php echo e(trans('library.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($book->title); ?></td>
                                                <td><?php echo e($book->teacher->Name); ?></td>
                                                <td><?php echo e($book->grade->Name); ?></td>
                                                <td><?php echo e($book->classroom->Name_class); ?></td>
                                                <td><?php echo e($book->section->Name_Section); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('downloadAttachment',$book->file_name)); ?>" title="تحميل الكتاب" class="btn btn-warning btn-sm" role="button" aria-pressed="true"><i class="fas fa-download"></i></a>
                                                    <a href="<?php echo e(route('library.edit',$book->id)); ?>" class="btn btn-info btn-sm" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>
                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_book<?php echo e($book->id); ?>" title="حذف"><i class="fa fa-trash"></i></button>
                                                </td>
                                            </tr>

                                        <?php echo $__env->make('pages.library.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\school-management-system\resources\views/pages/library/index.blade.php ENDPATH**/ ?>