<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('fees.Add new fees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('fees.Add new fees')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(route('Fees.store')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fees.Name_ar')); ?></label>
                                <input type="text" value="<?php echo e(old('title_ar')); ?>" name="title_ar" class="form-control">
                            </div>

                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fees.Name_en')); ?></label>
                                <input type="text" value="<?php echo e(old('title_en')); ?>" name="title_en" class="form-control">
                            </div>


                            <div class="form-group col">
                                <label for="inputEmail4"><?php echo e(trans('fees.the amount')); ?></label>
                                <input type="number" value="<?php echo e(old('amount')); ?>" name="amount" class="form-control">
                            </div>

                        </div>


                        <div class="form-row">

                            <div class="form-group col">
                                <label for="inputState"><?php echo e(trans('fees.Educational level')); ?></label>
                                <select class="custom-select mr-sm-2" name="Grade_id">
                                    <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                                    <?php $__currentLoopData = $Grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($Grade->id); ?>"><?php echo e($Grade->Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fees.Classroom')); ?></label>
                                <select class="custom-select mr-sm-2" name="Classroom_id">

                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fees.academic year')); ?></label>
                                <select class="custom-select mr-sm-2" name="year">
                                    <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                                    <?php
                                        $current_year = date("Y")
                                    ?>
                                    <?php for($year=$current_year; $year<=$current_year +1 ;$year++): ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="inputZip"><?php echo e(trans('fees.Fee type')); ?></label>
                                <select class="custom-select mr-sm-2" name="Fee_type">
                                    <option value="1"><?php echo e(trans('fees.Tuition fees')); ?></option>
                                    <option value="2"><?php echo e(trans('fees.bus fee')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputAddress"><?php echo e(trans('fees.Notes')); ?></label>
                            <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="4"></textarea>
                        </div>
                        <br>

                        <button type="submit" class="btn btn-primary"><?php echo e(trans('fees.Confirm')); ?></button>

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\school-management-system\resources\views/pages/Fees/add.blade.php ENDPATH**/ ?>