<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('fees.study fees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('fees.study fees')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('Fees.create')); ?>" class="btn btn-success btn-sm" role="button"
                                   aria-pressed="true"><?php echo e(trans('fees.Add new fees')); ?></a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr class="alert-success">
                                            <th>#</th>
                                            <th><?php echo e(trans('fees.name')); ?></th>
                                            <td>النوع</td>
                                            <th><?php echo e(trans('fees.the amount')); ?></th>
                                            <th><?php echo e(trans('fees.Educational level')); ?></th>
                                            <th><?php echo e(trans('fees.Classroom')); ?></th>
                                            <th><?php echo e(trans('fees.academic year')); ?></th>
                                            <th><?php echo e(trans('fees.Notes')); ?></th>
                                            <th><?php echo e(trans('fees.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($fee->title); ?></td>
                                            <td><?php echo e($fee->Fee_type); ?></td>
                                            <td><?php echo e(number_format($fee->amount, 2)); ?></td>
                                            <td><?php echo e($fee->grade->Name); ?></td>
                                            <td><?php echo e($fee->classroom->Name_class); ?></td>
                                            <td><?php echo e($fee->year); ?></td>
                                            <td><?php echo e($fee->description); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('Fees.edit',$fee->id)); ?>" class="btn btn-info btn-sm" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>
                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#Delete_Fee<?php echo e($fee->id); ?>" title="<?php echo e(trans('Grades_trans.Delete')); ?>"><i class="fa fa-trash"></i></button>
                                                    <a href="#" class="btn btn-warning btn-sm" role="button" aria-pressed="true"><i class="far fa-eye"></i></a>

                                                </td>
                                            </tr>
                                        <?php echo $__env->make('pages.Fees.Delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\school-management-system\resources\views/pages/Fees/index.blade.php ENDPATH**/ ?>