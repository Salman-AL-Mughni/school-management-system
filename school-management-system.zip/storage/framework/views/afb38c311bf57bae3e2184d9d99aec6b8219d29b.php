<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('Students_trans.studant_list')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.list_students')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('Students.create')); ?>" class="btn btn-success btn-sm" role="button"
                                   aria-pressed="true"> <?php echo e(trans('Students_trans.add_list')); ?></a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(trans('Students_trans.name')); ?></th>
                                            <th><?php echo e(trans('Students_trans.email')); ?></th>
                                            <th><?php echo e(trans('Students_trans.gender')); ?></th>
                                            <th><?php echo e(trans('Students_trans.Grade')); ?></th>
                                            <th><?php echo e(trans('Students_trans.classrooms')); ?></th>
                                            <th><?php echo e(trans('Students_trans.section')); ?></th>
                                            <th><?php echo e(trans('Students_trans.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index+1); ?></td>
                                                <td><?php echo e($student->name); ?></td>
                                                <td><?php echo e($student->email); ?></td>
                                                <td><?php echo e($student->gender->Name); ?></td>
                                                <td><?php echo e($student->grade->Name); ?></td>
                                                <td><?php echo e($student->classroom->Name_class); ?></td>
                                                <td><?php echo e($student->section->Name_Section); ?></td>

                                                <td>
                                                    <div class="dropdown show">
                                                    <a class="btn btn-success btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        العمليات
                                                    </a>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                        <a class="dropdown-item" href="<?php echo e(route('Students.show',$student->id)); ?>"><i style="color: #ffc107" class="far fa-eye "></i>&nbsp;  عرض بيانات الطالب</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('Students.edit',$student->id)); ?>"><i style="color:green" class="fa fa-edit"></i>&nbsp;  تعديل بيانات الطالب</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('Fees_Invoices.show',$student->id)); ?>"><i style="color: #0000cc" class="fa fa-edit"></i>&nbsp;اضافة فاتورة رسوم&nbsp;</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('receipt_students.show',$student->id)); ?>"><i style="color: #9dc8e2" class="fas fa-money-bill-alt"></i>&nbsp; &nbsp;سند قبض</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('ProcessingFee.show',$student->id)); ?>"><i style="color: #9dc8e2" class="fas fa-money-bill-alt"></i>&nbsp; &nbsp; استبعاد رسوم</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('Payment_students.show',$student->id)); ?>"><i style="color:goldenrod" class="fas fa-donate"></i>&nbsp; &nbsp;سند صرف</a>
                                                        <a class="dropdown-item" data-target="#Delete_Student<?php echo e($student->id); ?>" data-toggle="modal" href="##Delete_Student<?php echo e($student->id); ?>"><i style="color: red" class="fa fa-trash"></i>&nbsp;  حذف بيانات الطالب</a>
                                                    </div>
                                                </div>
                                                </td>


                                            </tr>
                                        <?php echo $__env->make('pages.Students.Delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\school-management-system\resources\views/pages/Students/index.blade.php ENDPATH**/ ?>