<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('Online classes.Online classes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('Online classes.Online classes')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('online_classes.create')); ?>" class="btn btn-success" role="button" aria-pressed="true"><?php echo e(trans('Online classes.Add a new online share')); ?></a>
                                <a class="btn btn-warning" href="<?php echo e(route('indirect.create')); ?>"><?php echo e(trans('Online classes.Add a new offline share')); ?></a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr class="alert-success">
                                            <th>#</th>
                                            <th><?php echo e(trans('Online classes.stage')); ?></th>
                                            <th><?php echo e(trans('Online classes.Classroom')); ?></th>
                                            <th><?php echo e(trans('Online classes.Section')); ?></th>
                                            <th><?php echo e(trans('Online classes.the teacher')); ?></th>
                                            <th><?php echo e(trans('Online classes.Class title')); ?></th>
                                            <th><?php echo e(trans('Online classes.Start Date')); ?></th>
                                            <th><?php echo e(trans('Online classes.class time')); ?></th>
                                            <th><?php echo e(trans('Online classes.share link')); ?></th>
                                            <th><?php echo e(trans('Online classes.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $online_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $online_classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($online_classe->grade->Name); ?></td>
                                            <td><?php echo e($online_classe->classroom->Name_class); ?></td>
                                            <td><?php echo e($online_classe->section->Name_Section); ?></td>
                                                <td><?php echo e($online_classe->user->name); ?></td>
                                                <td><?php echo e($online_classe->topic); ?></td>
                                                <td><?php echo e($online_classe->start_at); ?></td>
                                                <td><?php echo e($online_classe->duration); ?></td>
                                                <td class="text-danger"><a href="<?php echo e($online_classe->join_url); ?>" target="_blank">انضم الان</a></td>
                                                <td>
                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#Delete_receipt<?php echo e($online_classe->meeting_id); ?>" ><i class="fa fa-trash"></i></button>
                                                </td>
                                            </tr>
                                        <?php echo $__env->make('pages.online_classes.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\school-management-system\resources\views/pages/online_classes/index.blade.php ENDPATH**/ ?>