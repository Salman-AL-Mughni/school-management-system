<?php return array (
  'add-parent' => 'App\\Http\\Livewire\\AddParent',
  'counter' => 'App\\Http\\Livewire\\Counter',
);