<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class fund_account extends Model
{
    //
}
