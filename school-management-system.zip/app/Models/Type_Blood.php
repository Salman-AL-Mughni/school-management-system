<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Type_Blood extends Model
{
    protected $fillable=['Name'];
}
