<?php

return [

    'the library'=>'المكتبة',
    'Book List'=>'قائمة الكتب',
    'Add a new book'=>'اضافة كتاب جديد',
    'books name'=>'اسم الكتب',
    'name teacher'=>'اسم المعلم',
    'Educational level'=>'المرحلة الدراسية',
    'Classroom'=>'الصف الدراسي',
    'Section'=>'القسم',
    'Processes'=>'العمليات',
    'attachments'=>'المرفقات',
    'Saving data'=>'حفظ البيانات',
    'book edit'=>' تعديل كتاب',
    'delete a book'=>'حذف كتاب',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
