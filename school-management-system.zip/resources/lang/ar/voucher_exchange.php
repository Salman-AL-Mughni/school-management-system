<?php

return [

    'Bills of exchange'=>'سندات الصرف',
    'The name'=>'الاسم',
    'the amount'=>'المبلغ',
    'Statement'=>'البيان',
    'Processes'=>'العمليات',
    'Add a voucher'=>'اضافة سند صرف',
    'Student credit'=>'رصيد الطالب',
    'Edit voucher'=>'تعديل سند صرف',
    'Delete voucher'=>'حذف سند صرف',
    'Are you sure with the deletion process?'=>'هل انت متاكد مع عملية الحذف ؟',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
