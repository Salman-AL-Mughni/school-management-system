<?php

return [

    'exclude fee'=>'استبعاد رسوم',
    'Tuition Fee Processors'=>'معالجات الرسوم الدراسية',
    'The name'=>'الاسم',
    'the amount'=>'المبلغ',
    'Statement'=>'البيان',
    'Processes'=>'العمليات',
    'Student credit'=>'رصيد الطالب',
    'Delete processing fee'=>'حذف رسوم معالجة',
    'Are you sure with the deletion process?'=>'هل انت متاكد مع عملية الحذف ؟',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
