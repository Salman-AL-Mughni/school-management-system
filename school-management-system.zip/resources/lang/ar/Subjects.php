<?php

return [

    'Subjects'=>'المواد الدراسية',
    'Material List'=>'قائمة المواد',
    'Subject List'=>'قائمة المواد الدراسية',
    'Add a new article'=>'اضافة مادة جديدة',
    'Subject Name'=>'اسم المادة',
    'Educational level'=>'المرحلة الدراسية',
    'Classroom'=>'الصف الدراسي',
    'teacher name'=>'اسم المعلم',
    'Processes'=>'العمليات',
    'Delete a course'=>'حذف مادة دراسية',
    'Modify a course'=>'تعديل مادة دراسية',
    'Subject Name_ar'=>'اسم المادة باللغة العربية',
    'Subject Name_en'=>'اسم المادة باللغة الانجليزية',
    'Saving data'=>'حفظ البيانات',
    'Add a course'=>' اضافة مادة دراسية',
    ''=>'',
    ''=>'',
    ''=>'',
];
