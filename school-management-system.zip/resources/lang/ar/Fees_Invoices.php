<?php

return [

    'name'=>'اسم الطالب',
    'the amount'=>'المبلغ',
    'Educational level'=>'المرحلة الدراسية',
    'Classroom'=>'الصف الدراسي',
    'Processes'=>'العمليات',
    'Add new fees'=>'اضافة فاتورة جديدة',
    'study fees'=>' الرسوم الدراسية',
    'Tuition fee adjustment'=>'  تعديل فاتورة دراسية',
    'the amount'=>'المبلغ',
    'Confirm'=>'تاكيد',
    'Are you sure with the deletion process?'=>'هل انت متاكد مع عملية الحذف ؟',
    'Fee type'=>'نوع الرسوم',
    'Choose from the list'=>'اختار من القائمة',
    'Statement'=>'البيان',
    'Tuition fee adjustment'=>'تعديل رسوم دراسية',
    'Tuition bills'=>' الفواتير الدراسية',
    'Invoices'=>'الفواتير',
    'delete invoice'=>'حذف فاتورة',
];
