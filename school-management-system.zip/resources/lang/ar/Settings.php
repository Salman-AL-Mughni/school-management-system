<?php

return [

    'Settings'=>'الاعدادات',
    'School name'=>'اسم المدرسة',
    'current year'=>'العام الحالي',
    'School Short Name'=>'اسم المدرسة المختصر',
    'the phone'=>'الهاتف',
    'E-mail'=>'البريد الالكتروني',
    'school address'=>'عنوان المدرسة',
    'The end of the first term'=>'نهاية الترم الاول',
    'end of second term'=>'نهاية الترم الثاني',
    'school logo'=>'شعار المدرسة',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
