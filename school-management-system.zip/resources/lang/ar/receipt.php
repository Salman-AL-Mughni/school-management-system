<?php

return [
    'receipt'=>'سندات القبض',
    'The name'=>'الاسم',
    'the amount'=>'المبلغ',
    'Statement'=>'البيان',
    'Processes'=>'العمليات',
    'Catch Receipt'=>' سند قبض',
    'Amendment of receipt voucher'=>'تعديل سند قبض',
    'Delete a receipt voucher'=>'حذف سند قبض',
    'Are you sure with the deletion process?'=>'هل انت متاكد مع عملية الحذف ؟',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
