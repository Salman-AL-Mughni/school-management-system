<?php

return [
    'Attendance'=>'الحضور والغياب',
    'Student List'=>'قائمة الطلاب',
    'Presence'=>'حضور',
    'Absence'=>'غياب',
    'Student List'=>'قائمة الطلاب',
    'List of attendance'=>'  قائمة الحضور والغياب للطلاب',
    'today date'=>'تاريخ اليوم',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
