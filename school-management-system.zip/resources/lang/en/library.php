<?php

return [

    'the library'=>'the library',
    'Book List'=>'Book List',
    'Add a new book'=>'Add a new book',
    'books name'=>'books name',
    'name teacher'=>'name teacher',
    'Educational level'=>'Educational level',
    'Classroom'=>'Classroom',
    'Section'=>'Section',
    'Processes'=>'Processes',
    'attachments'=>'attachments',
    'Saving data'=>'Saving data',
    'book edit'=>' book edit',
    'delete a book'=>'delete a book',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
