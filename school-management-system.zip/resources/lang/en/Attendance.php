<?php

return [
    'Attendance'=>'Attendance',
    'Student List'=>'Student List',
    'Presence'=>'Presence',
    'Absence'=>'Absence',
    'Student List'=>'Student List',
    'List of attendance'=>'  List of attendance',
    'today date'=>'today date',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
