<?php

return [

    'Subjects'=>'Subjects',
    'Material List'=>'Material List',
    'Subject List'=>'Subject List',
    'Add a new article'=>'Add a new article',
    'Subject Name'=>'Subject Name',
    'Educational level'=>'Educational level',
    'Classroom'=>'Classroom',
    'teacher name'=>'teacher name',
    'Processes'=>'Processes',
    'Delete a course'=>'Delete a course',
    'Modify a course'=>'Modify a course',
    'Subject Name_ar'=>'Subject Name_ar',
    'Subject Name_en'=>'Subject Name_en',
    'Saving data'=>'Saving data',
    'Add a course'=>' Add a course',
    ''=>'',
    ''=>'',
    ''=>'',
];
