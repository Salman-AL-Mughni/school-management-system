<?php

return [

    'name'=>'name',
    'the amount'=>'the amount',
    'Educational level'=>'Educational level',
    'Classroom'=>'Classroom',
    'Processes'=>'Processes',
    'Add new fees'=>'Add new fees',
    'study fees'=>' study fees',
    'Tuition fee adjustment'=>'  Tuition fee adjustment',
    'the amount'=>'the amount',
    'Confirm'=>'Confirm',
    'Are you sure with the deletion process?'=>'Are you sure with the deletion process?',
    'Fee type'=>'Fee type',
    'Choose from the list'=>'Choose from the list',
    'Statement'=>'Statement',
    'Tuition fee adjustment'=>'Tuition fee adjustment',
    'Tuition bills'=>' Tuition bills',
    'Invoices'=>'Invoices',
    'delete invoice'=>'delete invoice',
];
