<?php

return [
    'success'=>'Data has been saved successfully!',
    'Update'=>'Data has been saved successfully!',
    'Delete'=>'Data has been saved successfully!',
];
