<?php

return [

    'title_page' => 'sections',
    'List_Grade' => 'List_Grade',
    'add_section' => 'Add Section ',
    'edit_Section'=> 'Edit Section',
    'delete_Section'=> 'Delete Section',
    'Warning_Section'=> 'Are Sure Of The Deleting Process ?',
    'Section_name_ar' => 'Section name Ar',
    'Section_name_en' => 'Section name En',
    'Select_Grade' => '-- Select Grade --',
    'Name_Grade' => 'Name Grade',
    'submit' => 'submit',
    'Name_Section'=>'Name Section',
    'Name_Class'=>'Name Class',
    'Name_Teacher'=>'Name Teacher',
    'Status'=>'Status',
    'Status_Section_AC'=>'Active',
    'Status_Section_No'=>'Not Active',
    'delete_Grade_Error'=>'The Grade cannot be deleted because there are classes attached to it',
    'required_ar'=>'Please Enter The Section Name in Arabic',
    'required_en'=>'Please Enter The Section Name in English',
    'Grade_id_required'=>'Please Select The Grade Name',
    'Class_id_required'=>'Please Select The Class Name',
    'Processes'=>'Processes',
    'Edit'=>'Edit',
    'Delete'=>'Delete',
    'Close' => 'Close',

];
