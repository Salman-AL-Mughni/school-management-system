<?php

return [

    'Bills of exchange'=>'Bills of exchange',
    'The name'=>'The name',
    'the amount'=>'the amount',
    'Statement'=>'Statement',
    'Processes'=>'Processes',
    'Add a voucher'=>'Add a voucher',
    'Student credit'=>'Student credit',
    'Edit voucher'=>'Edit voucher',
    'Delete voucher'=>'Delete voucher',
    'Are you sure with the deletion process?'=>'Are you sure with the deletion process?',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
