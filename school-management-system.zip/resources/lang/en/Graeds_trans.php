<?php

return [
    'title_page' => 'title_page',
    'List_Grade' => 'List_Grade',
    'add_Grade' => 'add_Grade',
    'edit_Grade'=> 'edit_Grade',
    'delete_Grade'=> 'delete_Grade',
    'Warning_Grade'=> 'Warning_Grade',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_Grade_Error'=>'delete_Grade_Error',
    'Edit'=>'Edit',
    'exists'=>'exists',
    'Delete'=>'Delete',
    'Close' => 'Close',
    'Components'=>' school management software',
    'exises'=>'This field already exists',
    'delete_Grade_Error'=>'The stage can be deleted because it has its own rows',


];
