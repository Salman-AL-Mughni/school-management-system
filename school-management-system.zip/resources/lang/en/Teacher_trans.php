<?php

return [
    'Name_Teacher'=>'Name Teacher',
    'Add_Teacher'=>'Add Teacher',
    'Edit_Teacher'=>'Edit Teacher',
    'Delete_Teacher'=>'Delete Teacher',
    'Email'=>'Email',
    'Password'=>'Password',
    'Name_ar'=>'Name_ar',
    'Name_en'=>'Name_en',
    'specialization'=>'specialization',
    'Gender'=>'Gender',
    'Joining_Date'=>'Joining_Date',
    'Address'=>'Address',
];
