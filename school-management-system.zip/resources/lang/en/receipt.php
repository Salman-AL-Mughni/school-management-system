<?php

return [
    'receipt'=>'receipt',
    'The name'=>'The name',
    'the amount'=>'the amount',
    'Statement'=>'Statement',
    'Processes'=>'Processes',
    'Catch Receipt'=>'Catch Receipt',
    'Amendment of receipt voucher'=>'Amendment of receipt voucher',
    'Delete a receipt voucher'=>'Delete a receipt voucher',
    'Are you sure with the deletion process?'=>'Are you sure with the deletion process?',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
