<?php

return [

    'Settings'=>'Settings',
    'School name'=>'School name',
    'current year'=>'current year',
    'School Short Name'=>'School Short Name',
    'the phone'=>'the phone',
    'E-mail'=>'E-mail',
    'school address'=>'school address',
    'The end of the first term'=>'The end of the first term',
    'end of second term'=>'end of second term',
    'school logo'=>'school logo',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
