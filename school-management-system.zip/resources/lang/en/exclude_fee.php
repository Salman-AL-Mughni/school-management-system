<?php

return [

    'exclude fee'=>'exclude fee',
    'Tuition Fee Processors'=>'Tuition Fee Processors',
    'The name'=>'The name',
    'the amount'=>'the amount',
    'Statement'=>'Statement',
    'Processes'=>'Processes',
    'Student credit'=>'Student credit',
    'Delete processing fee'=>'Delete processing fee',
    'Are you sure with the deletion process?'=>'Are you sure with the deletion process?',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
    ''=>'',
];
